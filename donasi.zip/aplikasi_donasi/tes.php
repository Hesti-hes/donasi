<?php
echo "Halo dari tes.php!";
?>